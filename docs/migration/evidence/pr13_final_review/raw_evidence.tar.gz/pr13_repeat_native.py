import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path('/tmp/pr13_native_review'); root.mkdir(exist_ok=False)
known=json.loads(Path('/tmp/phase2c_driver_public_before.json').read_text())
before={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in known}
(root/'driver_before.json').write_text(json.dumps(before,indent=2)+'\n')
summary=[]
for index,mode in enumerate(['plan','execute','mismatch','expired','foreign','cancel','silence','fault']):
    environment=os.environ.copy();environment['ROS_DOMAIN_ID']=str(201+index)
    environment['ROS_LOG_DIR']=str(root/f'ros_{mode}')
    with (root/f'{mode}.supervisor.log').open('x') as log:
        proc=subprocess.run([sys.executable,'src/mtc_phase2c_integration_cpp/scripts/run_fake_gate.py','--mode',mode,'--evidence',str(root/mode)],env=environment,stdout=log,stderr=subprocess.STDOUT,timeout=150)
    result=json.loads((root/mode/'results.json').read_text())
    row={k:result[k] for k in ['mode','functional','teardown','overall']};row['exit']=proc.returncode
    row['children']=[{'role':p['name'],'launcher':p['launcher_returncode'],'exit_codes':[e['returncode'] for e in p.get('child_events',[]) if e['event']=='exit']} for p in result['processes']]
    summary.append(row);(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(row),flush=True)
    if result['functional']!='PASS':
        print('Stopping: functional verification failed',flush=True);break
    if result['overall']!='FAIL' or proc.returncode!=1:
        print('Unexpected teardown outcome requires review',flush=True);break
after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in known}
(root/'driver_after.json').write_text(json.dumps(after,indent=2)+'\n')
print('Driver public files unchanged:',before==after,flush=True)
